module.exports = {
    url: "mongodb+srv://root:root123@bafna.sei7ii5.mongodb.net/?retryWrites=true&w=majority"
};